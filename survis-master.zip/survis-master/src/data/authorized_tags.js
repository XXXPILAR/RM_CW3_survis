const userDefinedAuthorizedTags = {
	"type:system": {
		"description": "paper describing a system"
	}
}